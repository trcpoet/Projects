import java.util.Scanner;

public class PresentValue {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // input values
        System.out.print("Enter future value: ");
        double futureValue = input.nextDouble();

        System.out.print("Enter annual interest rate: ");
        double annualInterestRate = input.nextDouble();

        System.out.print("Enter number of years: ");
        int numberOfYears = input.nextInt();

        // Calculating present value using the formula
        double presentValue = presentValue(futureValue, annualInterestRate, numberOfYears);

        // Displaying result
        System.out.printf("To have a future value of $%.2f in %d years " +
                        "with an annual interest rate of %.2f%%, you need to deposit $%.2f today.",
                futureValue, numberOfYears, annualInterestRate, presentValue);

        input.close();
    }

    public static double presentValue(double futureValue, double annualInterestRate, int numberOfYears) {
        // Calculate present value using the formula
        double presentValue = futureValue / Math.pow(1 + (annualInterestRate / 100), numberOfYears);

        return presentValue;
    }

}
