import java.util.Scanner;

public class TestAverageAndGrade1 {
    public static double calcAverage(double[] scores) {
        double sum = 0;
        for (double score : scores) {
            sum += score;
        }
        return sum / scores.length;
    }

    public static char determineGrade(double score) {
        if (score >= 90 && score <= 100) {
            return 'A';
        } else if (score >= 80 && score < 90) {
            return 'B';
        } else if (score >= 70 && score < 80) {
            return 'C';
        } else if (score >= 60 && score < 70) {
            return 'D';
        } else {
            return 'F';
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] scores = new double[5];

        // enter five test scores
        for (int i = 0; i < scores.length; i++) {
            System.out.print("Enter test score #" + (i + 1) + ": ");
            scores[i] = input.nextDouble();
        }

        //average test score
        double average = calcAverage(scores);

        //letter grade for each score and the average test score
        System.out.println("Test Scores:");
        for (double score : scores) {
            char grade = determineGrade(score);
            System.out.printf("%.1f\t%s%n", score, grade);
        }
        System.out.printf("Average Score: %.1f%n", average);
    }
}

