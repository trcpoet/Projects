public class TemperatureConverter {
    public static double celsius(double fahrenheit) {
        double celsius = 5.0 / 9.0 * (fahrenheit - 32);
        return celsius;
    }

    public static void main(String[] args) {
        //table headers
        System.out.printf("%-12s %-12s%n", "Fahrenheit", "Celsius");

        //table rows
        for (int fahrenheit = 0; fahrenheit <= 20; fahrenheit++) {
            double celsius = celsius(fahrenheit);
            System.out.printf("%-12d %-12.1f%n", fahrenheit, celsius);
        }
    }
}
